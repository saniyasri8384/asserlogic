
// Enhanced PDF Processing with Real Text Extraction
class PDFProcessor {
    constructor() {
        this.supportedTypes = AppConfig.SUPPORTED_FORMATS;
        this.maxFileSize = AppConfig.MAX_FILE_SIZE;
        this.loadPDFJS();
    }

    async loadPDFJS() {
        if (!window.pdfjsLib) {
            try {
                const script = document.createElement('script');
                script.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
                document.head.appendChild(script);

                await new Promise((resolve, reject) => {
                    script.onload = resolve;
                    script.onerror = reject;
                });

                window.pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
                console.log('PDF.js loaded successfully');
            } catch (error) {
                console.error('Failed to load PDF.js:', error);
                throw new Error('PDF processing library failed to load');
            }
        }
    }

    validateFile(file) {
        const errors = [];

        if (!file) {
            errors.push('No file selected');
            return { valid: false, errors };
        }

        if (!this.supportedTypes.includes(file.type)) {
            errors.push('Only PDF files are supported');
        }

        if (file.size > this.maxFileSize) {
            errors.push(`File size exceeds ${Utils.formatFileSize(this.maxFileSize)} limit`);
        }

        return {
            valid: errors.length === 0,
            errors
        };
    }

    async extractTextFromPDF(file) {
        try {
            await this.loadPDFJS();

            const arrayBuffer = await file.arrayBuffer();
            const pdf = await window.pdfjsLib.getDocument(arrayBuffer).promise;

            let fullText = '';
            const totalPages = pdf.numPages;

            Utils.showNotification(`Processing ${totalPages} pages...`, 'info', 2000);

            for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
                const page = await pdf.getPage(pageNum);
                const textContent = await page.getTextContent();

                const pageText = textContent.items
                    .map(item => item.str)
                    .join(' ')
                    .replace(/\s+/g, ' ')
                    .trim();

                fullText += pageText + '\n\n';

                // Update progress
                if (pageNum % 5 === 0 || pageNum === totalPages) {
                    const progress = Math.round((pageNum / totalPages) * 100);
                    console.log(`PDF processing progress: ${progress}%`);
                }
            }

            fullText = this.cleanExtractedText(fullText);

            if (fullText.length < 100) {
                throw new Error('Insufficient text extracted from PDF. The document may be image-based or corrupted.');
            }

            Utils.showNotification(`Successfully extracted ${Utils.formatFileSize(fullText.length)} of text`, 'success');
            return fullText;

        } catch (error) {
            console.error('PDF text extraction error:', error);
            throw new Error(`Failed to extract text from PDF: ${error.message}`);
        }
    }

    cleanExtractedText(text) {
        return text
            .replace(/\s+/g, ' ')
            .replace(/[\f\r]/g, ' ')
            .replace(/([a-z])([A-Z])/g, '$1 $2')
            .replace(/\s+[a-zA-Z]\s+/g, ' ')
            .replace(/\s+([,.!?;:])/g, '$1')
            .replace(/([,.!?;:])\s*/g, '$1 ')
            .trim();
    }

    async getDetailedMetadata(file) {
        try {
            await this.loadPDFJS();

            const arrayBuffer = await file.arrayBuffer();
            const pdf = await window.pdfjsLib.getDocument(arrayBuffer).promise;
            const metadata = await pdf.getMetadata();

            return {
                name: file.name,
                size: file.size,
                type: file.type,
                lastModified: new Date(file.lastModified),
                pages: pdf.numPages,
                title: metadata.info.Title || 'Unknown',
                author: metadata.info.Author || 'Unknown',
                creator: metadata.info.Creator || 'Unknown',
                producer: metadata.info.Producer || 'Unknown',
                creationDate: metadata.info.CreationDate || null,
                modificationDate: metadata.info.ModDate || null,
                pdfVersion: pdf.pdfInfo.version || 'Unknown'
            };
        } catch (error) {
            console.error('Metadata extraction error:', error);
            return {
                name: file.name,
                size: file.size,
                type: file.type,
                lastModified: new Date(file.lastModified),
                pages: 'Unknown',
                title: 'Unknown',
                author: 'Unknown'
            };
        }
    }
}

window.PDFProcessor = PDFProcessor;