// Simplified Ballpit Animation for Get Started Page
class SimpleBallpitAnimation {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        this.balls = [];
        this.animationId = null;
        this.mouse = { x: 0, y: 0 };

        this.init();
    }

    init() {
        this.setupCanvas();
        this.createBalls();
        this.setupEventListeners();
        this.animate();
    }

    setupCanvas() {
        const resize = () => {
            this.canvas.width = window.innerWidth;
            this.canvas.height = window.innerHeight;
        };

        resize();
        window.addEventListener('resize', resize);
    }

    createBalls() {
        const ballCount = Math.min(60, Math.floor(window.innerWidth / 20));
        const colors = [
            '#667eea', '#764ba2', '#f093fb', '#f5576c',
            '#4facfe', '#00f2fe', '#43e97b', '#38f9d7'
        ];

        for (let i = 0; i < ballCount; i++) {
            this.balls.push({
                x: Math.random() * this.canvas.width,
                y: Math.random() * this.canvas.height,
                radius: Math.random() * 12 + 4,
                vx: (Math.random() - 0.5) * 1.5,
                vy: (Math.random() - 0.5) * 1.5,
                color: colors[Math.floor(Math.random() * colors.length)],
                alpha: Math.random() * 0.5 + 0.3,
                glowSize: Math.random() * 0.5 + 0.5
            });
        }
    }

    setupEventListeners() {
        this.canvas.addEventListener('mousemove', (e) => {
            const rect = this.canvas.getBoundingClientRect();
            this.mouse.x = e.clientX - rect.left;
            this.mouse.y = e.clientY - rect.top;
        });

        this.canvas.addEventListener('click', (e) => {
            // Add explosion effect on click
            const rect = this.canvas.getBoundingClientRect();
            const clickX = e.clientX - rect.left;
            const clickY = e.clientY - rect.top;

            this.balls.forEach(ball => {
                const dx = ball.x - clickX;
                const dy = ball.y - clickY;
                const distance = Math.sqrt(dx * dx + dy * dy);

                if (distance < 150) {
                    const force = (150 - distance) / 150;
                    ball.vx += (dx / distance) * force * 3;
                    ball.vy += (dy / distance) * force * 3;
                }
            });
        });
    }

    updateBalls() {
        this.balls.forEach(ball => {
            // Update position
            ball.x += ball.vx;
            ball.y += ball.vy;

            // Mouse interaction
            const dx = ball.x - this.mouse.x;
            const dy = ball.y - this.mouse.y;
            const distance = Math.sqrt(dx * dx + dy * dy);

            if (distance < 100) {
                const force = (100 - distance) / 100;
                ball.vx += (dx / distance) * force * 0.3;
                ball.vy += (dy / distance) * force * 0.3;
            }

            // Bounce off walls
            if (ball.x + ball.radius > this.canvas.width || ball.x - ball.radius < 0) {
                ball.vx *= -0.7;
                ball.x = Math.max(ball.radius, Math.min(this.canvas.width - ball.radius, ball.x));
            }
            if (ball.y + ball.radius > this.canvas.height || ball.y - ball.radius < 0) {
                ball.vy *= -0.7;
                ball.y = Math.max(ball.radius, Math.min(this.canvas.height - ball.radius, ball.y));
            }

            // Add subtle gravity and friction
            ball.vy += 0.05;
            ball.vx *= 0.998;
            ball.vy *= 0.998;

            // Keep velocities reasonable
            const maxVelocity = 3;
            const currentVelocity = Math.sqrt(ball.vx * ball.vx + ball.vy * ball.vy);
            if (currentVelocity > maxVelocity) {
                ball.vx = (ball.vx / currentVelocity) * maxVelocity;
                ball.vy = (ball.vy / currentVelocity) * maxVelocity;
            }
        });
    }

    drawBalls() {
        this.balls.forEach(ball => {
            // Draw glow effect
            const glowGradient = this.ctx.createRadialGradient(
                ball.x, ball.y, 0,
                ball.x, ball.y, ball.radius * 3 * ball.glowSize
            );
            glowGradient.addColorStop(0, `${ball.color}${Math.floor(ball.alpha * 127).toString(16).padStart(2, '0')}`);
            glowGradient.addColorStop(1, 'transparent');

            this.ctx.fillStyle = glowGradient;
            this.ctx.beginPath();
            this.ctx.arc(ball.x, ball.y, ball.radius * 3 * ball.glowSize, 0, Math.PI * 2);
            this.ctx.fill();

            // Draw main ball
            this.ctx.fillStyle = `${ball.color}${Math.floor((ball.alpha + 0.3) * 255).toString(16).padStart(2, '0')}`;
            this.ctx.beginPath();
            this.ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
            this.ctx.fill();

            // Add highlight
            const highlightGradient = this.ctx.createRadialGradient(
                ball.x - ball.radius * 0.3, ball.y - ball.radius * 0.3, 0,
                ball.x, ball.y, ball.radius
            );
            highlightGradient.addColorStop(0, `rgba(255, 255, 255, ${ball.alpha * 0.6})`);
            highlightGradient.addColorStop(1, 'transparent');

            this.ctx.fillStyle = highlightGradient;
            this.ctx.beginPath();
            this.ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
            this.ctx.fill();
        });
    }

    animate() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        this.updateBalls();
        this.drawBalls();

        this.animationId = requestAnimationFrame(() => this.animate());
    }

    destroy() {
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
        }
        window.removeEventListener('resize', this.setupCanvas);
    }
}

// Initialize animation when DOM is loaded
let ballpitAnimation;

function initBallpitAnimation() {
    ballpitAnimation = new SimpleBallpitAnimation('ballpit-canvas');
}

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    if (ballpitAnimation) {
        ballpitAnimation.destroy();
    }
});