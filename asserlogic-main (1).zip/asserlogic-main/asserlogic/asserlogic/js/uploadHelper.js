// Upload Helper Functions
class UploadHelper {
    static showUploadGuide() {
        const guide = `
📄 HOW TO UPLOAD PDF FILES:

Method 1 - Drag & Drop:
• Drag PDF file from your computer
• Drop it on the upload area
• File will be automatically selected

Method 2 - Click Browse:
• Click "Browse Files" button
• Select PDF from file dialog
• Click "Open" to upload

Requirements:
• File must be PDF format (.pdf)
• Maximum size: 25MB
• Text-based PDFs work best
        `;

        Utils.showNotification(guide.replace(/\n/g, '<br>'), 'info', 8000);
    }

    static validateUpload(file) {
        if (!file) {
            Utils.showNotification('❌ No file selected. Please choose a PDF file.', 'error');
            return false;
        }

        if (file.type !== 'application/pdf') {
            Utils.showNotification('❌ Invalid file type. Please select a PDF file.', 'error');
            return false;
        }

        if (file.size > AppConfig.MAX_FILE_SIZE) {
            Utils.showNotification(`❌ File too large. Maximum size is ${Utils.formatFileSize(AppConfig.MAX_FILE_SIZE)}.`, 'error');
            return false;
        }

        Utils.showNotification(`✅ File "${file.name}" uploaded successfully! Size: ${Utils.formatFileSize(file.size)}`, 'success');
        return true;
    }

    static createFilePreview(file) {
        return {
            name: file.name,
            size: Utils.formatFileSize(file.size),
            type: file.type,
            lastModified: Utils.formatDate(file.lastModified),
            id: Utils.generateId()
        };
    }

    static getFileIcon(fileType) {
        const icons = {
            'application/pdf': 'fas fa-file-pdf',
            'text/plain': 'fas fa-file-alt',
            'application/msword': 'fas fa-file-word',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'fas fa-file-word',
            'default': 'fas fa-file'
        };
        return icons[fileType] || icons.default;
    }

    static handleFileError(error) {
        console.error('File handling error:', error);
        Utils.showNotification(`File error: ${error.message}`, 'error');
    }
}

window.UploadHelper = UploadHelper;