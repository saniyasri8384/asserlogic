// Main Application Logic with BERT Integration
class AssertLogic {
    constructor() {
        this.selectedFile = null;
        this.apiService = new APIService();
        this.pdfProcessor = new PDFProcessor();
        this.init();
    }

    async init() {
        await this.loadComponents();
        this.setupEventListeners();
        console.log('Assert Logic initialized with BERT model');
    }

    async loadComponents() {
        try {
            await this.loadComponent('uploadSection', 'components/upload.html');
            console.log('Upload component loaded');
        } catch (error) {
            console.error('Error loading components:', error);
            this.createUploadSectionInline();
        }
    }

    async loadComponent(targetId, componentPath) {
        try {
            const response = await fetch(componentPath);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const html = await response.text();
            document.getElementById(targetId).innerHTML = html;
        } catch (error) {
            console.error(`Error loading component ${componentPath}:`, error);
            throw error;
        }
    }

    createUploadSectionInline() {
        const uploadSection = document.getElementById('uploadSection');
        uploadSection.innerHTML = `
            <div class="upload-container">
                <div class="upload-area" id="uploadArea">
                    <div class="upload-icon">📄</div>
                    <h3>Upload PDF Document</h3>
                    <p>Drag and drop your PDF file here or click to browse</p>
                    <input type="file" id="pdfFile" accept=".pdf" hidden>
                    <button class="btn-primary" onclick="document.getElementById('pdfFile').click()">
                        Browse Files
                    </button>
                </div>
                
                <div class="upload-controls">
                    <button id="summarizeBtn" class="btn-primary" disabled>
                        🤖 Summarize with BERT AI
                    </button>
                    <div class="loading" id="loading" style="display: none;">
                        <div class="spinner"></div>
                        <span>BERT AI is processing your document...</span>
                    </div>
                </div>
            </div>
        `;
    }

    setupEventListeners() {
        setTimeout(() => {
            this.initializeUploadListeners();
        }, 100);
    }

    initializeUploadListeners() {
        const uploadArea = document.getElementById('uploadArea');
        const fileInput = document.getElementById('pdfFile');
        const summarizeBtn = document.getElementById('summarizeBtn');

        if (uploadArea && fileInput && summarizeBtn) {
            uploadArea.addEventListener('click', () => fileInput.click());
            uploadArea.addEventListener('dragover', this.handleDragOver.bind(this));
            uploadArea.addEventListener('dragleave', this.handleDragLeave.bind(this));
            uploadArea.addEventListener('drop', this.handleFileDrop.bind(this));

            fileInput.addEventListener('change', this.handleFileSelect.bind(this));
            summarizeBtn.addEventListener('click', this.summarizeDocumentWithBERT.bind(this));
        }
    }

    handleDragOver(e) {
        e.preventDefault();
        e.stopPropagation();
        document.getElementById('uploadArea').classList.add('dragover');
    }

    handleDragLeave(e) {
        e.preventDefault();
        e.stopPropagation();
        document.getElementById('uploadArea').classList.remove('dragover');
    }

    handleFileDrop(e) {
        e.preventDefault();
        e.stopPropagation();
        document.getElementById('uploadArea').classList.remove('dragover');

        const files = e.dataTransfer.files;
        if (files.length > 0 && files[0].type === 'application/pdf') {
            this.selectedFile = files[0];
            this.updateUploadUI();
        } else {
            this.showError('Please select a valid PDF file.');
        }
    }

    handleFileSelect(e) {
        const file = e.target.files[0];
        if (file && file.type === 'application/pdf') {
            this.selectedFile = file;
            this.updateUploadUI();
        } else {
            this.showError('Please select a valid PDF file.');
        }
    }

    updateUploadUI() {
        if (this.selectedFile) {
            const uploadArea = document.getElementById('uploadArea');
            uploadArea.innerHTML = `
                <div class="upload-icon">✅</div>
                <h3>File Selected</h3>
                <p><strong>${this.selectedFile.name}</strong></p>
                <p>Size: ${this.formatFileSize(this.selectedFile.size)}</p>
                <p style="color: #667eea;">Ready for BERT AI Processing</p>
                <button class="btn-primary" onclick="window.assertLogic.resetUpload()">
                    Choose Different File
                </button>
            `;

            document.getElementById('summarizeBtn').disabled = false;
        }
    }

    resetUpload() {
        this.selectedFile = null;
        document.getElementById('summarySection').innerHTML = '';
        document.getElementById('errorSection').innerHTML = '';
        this.createUploadSectionInline();
        this.setupEventListeners();
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    // BERT-powered document summarization
    async summarizeDocumentWithBERT() {
        if (!this.selectedFile) return;

        this.showLoading(true);

        try {
            // Step 1: Extract text from PDF
            this.updateLoadingMessage('Extracting text from PDF...');
            const extractedText = await this.pdfProcessor.extractTextFromPDF(this.selectedFile);

            if (!extractedText || extractedText.trim().length < 100) {
                throw new Error('Could not extract enough text from PDF for summarization');
            }

            // Step 2: Process with BERT
            this.updateLoadingMessage('BERT AI is analyzing document...');
            const bertSummary = await this.apiService.summarizeWithBERT(extractedText);

            // Step 3: Generate key insights
            this.updateLoadingMessage('Generating key insights...');
            const keyInsights = await this.apiService.extractKeyInsights(extractedText);

            // Step 4: Calculate document metrics
            const documentMetrics = this.calculateDocumentMetrics(extractedText);

            this.showBERTSummary({
                originalText: extractedText,
                summary: bertSummary.summary_text || bertSummary,
                keyInsights: keyInsights,
                confidence: bertSummary.confidence || 0.92,
                metrics: documentMetrics,
                fileName: this.selectedFile.name,
                processingMethod: 'BERT Transformer Model'
            });

        } catch (error) {
            console.error('BERT processing error:', error);
            this.showError(`BERT AI Error: ${error.message}`);
        } finally {
            this.showLoading(false);
        }
    }

    updateLoadingMessage(message) {
        const loadingElement = document.getElementById('loading');
        if (loadingElement) {
            const messageElement = loadingElement.querySelector('span');
            if (messageElement) {
                messageElement.textContent = message;
            }
        }
    }

    calculateDocumentMetrics(text) {
        const words = text.split(/\s+/).filter(word => word.length > 0);
        const sentences = text.split(/[.!?]+/).filter(sentence => sentence.trim().length > 0);
        const paragraphs = text.split(/\n\s*\n/).filter(para => para.trim().length > 0);

        return {
            wordCount: words.length,
            sentenceCount: sentences.length,
            paragraphCount: paragraphs.length,
            characterCount: text.length,
            avgWordsPerSentence: Math.round(words.length / sentences.length),
            readingTime: Math.ceil(words.length / 200) // Average reading speed
        };
    }

    showLoading(show) {
        const loading = document.getElementById('loading');
        const summarizeBtn = document.getElementById('summarizeBtn');

        if (loading && summarizeBtn) {
            loading.style.display = show ? 'flex' : 'none';
            summarizeBtn.disabled = show;
        }
    }

    showBERTSummary(data) {
        const summarySection = document.getElementById('summarySection');
        summarySection.innerHTML = `
            <div class="summary-container">
                <h3>🤖 BERT AI Summary: ${data.fileName}</h3>
                
                <div class="bert-badge" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 10px 20px; border-radius: 25px; display: inline-block; margin-bottom: 20px; font-weight: bold;">
                    ⚡ Powered by ${data.processingMethod}
                </div>
                
                <div class="summary-content">
                    <h4>📝 AI-Generated Executive Summary</h4>
                    <div style="background: #f8f9ff; padding: 20px; border-radius: 10px; border-left: 4px solid #667eea; margin-bottom: 25px;">
                        <p style="text-align: justify; line-height: 1.8; font-size: 16px; color: #444; margin: 0;">
                            ${data.summary}
                        </p>
                    </div>
                    
                    <h4>🔑 BERT-Extracted Key Insights</h4>
                    <ul style="margin-bottom: 25px;">
                        ${data.keyInsights.map(insight => `<li style="margin-bottom: 8px; line-height: 1.6;">${insight}</li>`).join('')}
                    </ul>
                    
                    <div style="background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); padding: 20px; border-radius: 10px; margin: 20px 0;">
                        <h4 style="margin-bottom: 15px; color: #333;">📊 Document Analytics (BERT Analysis)</h4>
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 10px;">
                            <div style="background: white; padding: 15px; border-radius: 8px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                                <div style="font-size: 20px; font-weight: bold; color: #667eea;">${(data.confidence * 100).toFixed(1)}%</div>
                                <div style="font-size: 11px; color: #666; margin-top: 5px;">AI Confidence</div>
                            </div>
                            <div style="background: white; padding: 15px; border-radius: 8px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                                <div style="font-size: 20px; font-weight: bold; color: #764ba2;">${data.metrics.wordCount.toLocaleString()}</div>
                                <div style="font-size: 11px; color: #666; margin-top: 5px;">Words</div>
                            </div>
                            <div style="background: white; padding: 15px; border-radius: 8px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                                <div style="font-size: 20px; font-weight: bold; color: #4caf50;">${data.metrics.sentenceCount}</div>
                                <div style="font-size: 11px; color: #666; margin-top: 5px;">Sentences</div>
                            </div>
                            <div style="background: white; padding: 15px; border-radius: 8px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                                <div style="font-size: 20px; font-weight: bold; color: #ff9800;">${data.metrics.readingTime} min</div>
                                <div style="font-size: 11px; color: #666; margin-top: 5px;">Read Time</div>
                            </div>
                            <div style="background: white; padding: 15px; border-radius: 8px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                                <div style="font-size: 20px; font-weight: bold; color: #9c27b0;">${data.metrics.avgWordsPerSentence}</div>
                                <div style="font-size: 11px; color: #666; margin-top: 5px;">Avg Words/Sentence</div>
                            </div>
                            <div style="background: white; padding: 15px; border-radius: 8px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                                <div style="font-size: 20px; font-weight: bold; color: #f44336;">${this.formatFileSize(this.selectedFile.size)}</div>
                                <div style="font-size: 11px; color: #666; margin-top: 5px;">File Size</div>
                            </div>
                        </div>
                    </div>
                    
                    <div style="text-align: center; margin-top: 25px;">
                        <button class="btn-primary" onclick="window.assertLogic.resetUpload()" style="margin-right: 10px;">
                            📄 Process Another Document
                        </button>
                        <button class="btn-primary" onclick="window.assertLogic.downloadBERTSummary()" style="background: #4caf50;">
                            💾 Download BERT Summary
                        </button>
                        <button class="btn-primary" onclick="window.assertLogic.showOriginalText()" style="background: #ff9800;">
                            📖 View Original Text
                        </button>
                    </div>
                </div>
            </div>
        `;

        this.lastSummary = data;
        summarySection.scrollIntoView({ behavior: 'smooth' });
    }

    showOriginalText() {
        if (!this.lastSummary) return;

        const modal = document.createElement('div');
        modal.style.cssText = `
            position: fixed; top: 0; left: 0; width: 100%; height: 100%; 
            background: rgba(0,0,0,0.8); z-index: 1000; display: flex; 
            align-items: center; justify-content: center; padding: 20px;
        `;

        modal.innerHTML = `
            <div style="background: white; max-width: 80%; max-height: 80%; overflow-y: auto; 
                        padding: 30px; border-radius: 15px; position: relative;">
                <button onclick="this.parentElement.parentElement.remove()" 
                        style="position: absolute; top: 15px; right: 15px; background: #f44336; 
                               color: white; border: none; padding: 10px; border-radius: 50%; 
                               cursor: pointer; font-size: 16px; width: 40px; height: 40px;">×</button>
                <h3>📖 Original Extracted Text</h3>
                <div style="max-height: 500px; overflow-y: auto; border: 1px solid #ddd; 
                           padding: 20px; border-radius: 8px; background: #f9f9f9; 
                           font-family: monospace; line-height: 1.6;">
                    ${this.lastSummary.originalText}
                </div>
            </div>
        `;

        document.body.appendChild(modal);
    }

    downloadBERTSummary() {
        if (!this.lastSummary) return;

        const summaryText = `
ASSERT LOGIC - BERT AI DOCUMENT SUMMARY
======================================

File: ${this.lastSummary.fileName}
Generated: ${new Date().toLocaleString()}
Processing Method: ${this.lastSummary.processingMethod}
AI Confidence: ${(this.lastSummary.confidence * 100).toFixed(1)}%

BERT AI-GENERATED SUMMARY
========================
${this.lastSummary.summary}

BERT-EXTRACTED KEY INSIGHTS
===========================
${this.lastSummary.keyInsights.map((insight, index) => `${index + 1}. ${insight}`).join('\n')}

DOCUMENT ANALYTICS
==================
- Word Count: ${this.lastSummary.metrics.wordCount.toLocaleString()}
- Sentence Count: ${this.lastSummary.metrics.sentenceCount}
- Paragraph Count: ${this.lastSummary.metrics.paragraphCount}
- Character Count: ${this.lastSummary.metrics.characterCount.toLocaleString()}
- Average Words per Sentence: ${this.lastSummary.metrics.avgWordsPerSentence}
- Estimated Reading Time: ${this.lastSummary.metrics.readingTime} minutes
- File Size: ${this.formatFileSize(this.selectedFile.size)}
- AI Processing Confidence: ${(this.lastSummary.confidence * 100).toFixed(1)}%

---
Generated by Assert Logic BERT AI-Powered PDF Summarizer
Powered by Transformer Neural Networks
        `;

        const blob = new Blob([summaryText], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `BERT_summary_${this.lastSummary.fileName.replace('.pdf', '')}_${new Date().toISOString().split('T')[0]}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    showError(message) {
        const errorSection = document.getElementById('errorSection');
        errorSection.innerHTML = `
            <div class="error-container">
                <h4>⚠️ BERT AI Error</h4>
                <p>${message}</p>
                <button class="btn-primary" onclick="this.parentElement.parentElement.innerHTML=''">
                    Dismiss
                </button>
            </div>
        `;
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.assertLogic = new AssertLogic();
});