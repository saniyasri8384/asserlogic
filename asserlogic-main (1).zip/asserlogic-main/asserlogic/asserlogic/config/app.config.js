// Application Configuration for BERT Integration
const AppConfig = {
    APP_NAME: 'Assert Logic BERT AI',
    VERSION: '2.0.0',

    // API Configuration
    HUGGINGFACE_API_KEY: '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',
    OPENAI_API_KEY: '', // Optional - leave empty if not using OpenAI
    AI_PROVIDER: 'huggingface', // 'huggingface' or 'openai' or 'local'

    // File Processing
    MAX_FILE_SIZE: 25 * 1024 * 1024, // 25MB
    SUPPORTED_FORMATS: ['application/pdf'],

    // BERT Model Configuration
    BERT_MODELS: {
        summarization: 'facebook/bart-large-cnn',
        keyExtraction: 'ml6team/keyphrase-extraction-kbir-inspec',
        sentiment: 'cardiffnlp/twitter-roberta-base-sentiment-latest',
        textClassification: 'microsoft/DialoGPT-medium'
    },

    // Processing Options
    SUMMARIZATION_OPTIONS: {
        max_length: 300,
        min_length: 50,
        do_sample: false,
        early_stopping: true,
        num_beams: 4,
        temperature: 0.7,
        repetition_penalty: 1.2
    },

    // API Settings
    API_SETTINGS: {
        timeout: 30000, // 30 seconds
        retryAttempts: 3,
        retryDelay: 2000, // 2 seconds
        maxChunkSize: 1000, // words per chunk
        enableFallback: true
    },

    // Local AI Fallback
    LOCAL_AI_MODE: false, // Set to true if you want to use local processing as backup
    LOCAL_NLP: {
        enableSmartSummarization: true,
        enableKeywordExtraction: true,
        enableSentimentAnalysis: true,
        summaryRatio: 0.3,
        minSentenceLength: 20,
        maxSummaryLength: 500
    },

    // Features
    FEATURES: {
        dragAndDrop: true,
        batchProcessing: false,
        realTimePreview: true,
        bertProcessing: true,
        downloadSummary: true,
        viewOriginalText: true,
        sentimentAnalysis: true,
        keywordExtraction: true,
        multiLanguageSupport: false
    },

    // UI Configuration
    UI_CONFIG: {
        theme: 'modern',
        showProcessingSteps: true,
        enableAnimations: true,
        showConfidenceScores: true,
        enableDebugMode: false
    },

    // Error Messages
    ERROR_MESSAGES: {
        apiKeyMissing: 'Hugging Face API key is required for BERT processing',
        fileTooBig: 'File size exceeds the maximum limit',
        invalidFormat: 'Only PDF files are supported',
        extractionFailed: 'Failed to extract text from PDF',
        apiError: 'BERT API processing failed',
        networkError: 'Network connection error'
    }
};

window.AppConfig = AppConfig;
window.AppConfig = AppConfig;
window.AppConfig = AppConfig;