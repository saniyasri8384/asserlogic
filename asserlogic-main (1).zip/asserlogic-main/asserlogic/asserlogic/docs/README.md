# Assert Logic - AI-Powered PDF Summarizer

![Assert Logic Logo](https://img.shields.io/badge/Assert%20Logic-BERT%20AI-blue)
![Version](https://img.shields.io/badge/version-1.0.0-green)
![License](https://img.shields.io/badge/license-MIT-blue)

## 🚀 Overview

Assert Logic is an advanced AI-powered PDF document summarizer that leverages BERT (Bidirectional Encoder Representations from Transformers) neural networks to provide intelligent document analysis and summarization.

## ✨ Features

- 🧠 **BERT AI Integration** - Advanced neural network processing
- 📄 **PDF Text Extraction** - Real-time PDF parsing and text extraction
- 🎨 **Modern UI/UX** - Beautiful interface with animated backgrounds
- 📱 **Responsive Design** - Works on desktop, tablet, and mobile
- ⚡ **Fast Processing** - Optimized for quick document analysis
- 🔒 **Secure** - Client-side processing for privacy

## 🛠️ Technologies Used

- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **AI/ML**: BERT Transformer Models
- **PDF Processing**: PDF.js library
- **Animation**: Three.js with custom ballpit animation
- **Styling**: Modern CSS with gradients and animations

## 🏗️ Project Structure

```
asserlogic/
├── components/          # Reusable HTML components
├── config/             # Configuration files
├── css/               # Stylesheets
├── docs/              # Documentation
├── js/                # JavaScript modules
├── index.html         # Main application
├── landing.html       # Get started page
└── contact.html       # Contact page
```

## 🚀 Getting Started

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/assert-logic.git
   cd assert-logic
   ```

2. **Open in browser**
   ```bash
   # Simply open landing.html in your browser
   # Or serve with a local server
   python -m http.server 8000
   ```

3. **Upload PDF**
   - Navigate to the application
   - Upload your PDF document
   - Click "Summarize with BERT AI"
   - Get your AI-generated summary

## 📁 Key Files

- [`js/pdfProcessor.js`](js/pdfProcessor.js) - PDF text extraction and processing
- [`js/ballpitAnimation.js`](js/ballpitAnimation.js) - Three.js background animation
- [`css/getstarted.css`](css/getstarted.css) - Landing page styles
- [`config/app.config.js`](config/app.config.js) - Application configuration

## 🌟 Demo

Visit the live demo: [Assert Logic Demo](https://yourusername.github.io/assert-logic)

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 👨‍💻 Author

**Your Name**
- GitHub: [@yourusername](https://github.com/yourusername)
- Email: your.email@example.com

## 🙏 Acknowledgments

- BERT AI model by Google Research
- PDF.js by Mozilla
- Three.js community
- Font Awesome for icons