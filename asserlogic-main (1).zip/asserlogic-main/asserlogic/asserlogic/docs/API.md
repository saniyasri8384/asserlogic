# API Documentation

## Endpoints

### POST /summarize
Summarize text content

**Request:**
```json
{
  "text": "Document text content",
  "options": {
    "length": "medium",
    "style": "formal"
  }
}
```

**Response:**
```json
{
  "summary": "Generated summary",
  "keyPoints": ["Point 1", "Point 2"],
  "confidence": 0.95
}
```